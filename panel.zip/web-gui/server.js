import express from 'express';
import path from 'path';
import fs from 'fs';
import os from 'os';
import { spawn, exec } from 'child_process';
import { fileURLToPath } from 'url';
import axios from 'axios';
import AdmZip from 'adm-zip';
import { db, bucket } from './firebase.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

let botProcess = null;

// Helper to get config path
const configPath = path.resolve(__dirname, '../settings/config.main.json');

// Read config dynamically to get APPSTATE_PATH
const getAppStatePath = () => {
    try {
        const cfg = JSON.parse(fs.readFileSync(configPath, 'utf8'));
        return path.resolve(__dirname, '..', cfg.APPSTATE_PATH || 'appstate.json');
    } catch (e) {
        return path.resolve(__dirname, '../appstate.json');
    }
};

app.get('/api/system/status', (req, res) => {
    const isInstalled = fs.existsSync(path.resolve(__dirname, '../nvsoftware.js'));
    const osType = os.type();
    const osPlatform = os.platform();
    const osRelease = os.release();
    const osArch = os.arch();

    res.json({
        installed: isInstalled,
        osInfo: `${osType} ${osRelease} (${osPlatform} ${osArch})`
    });
});

app.get('/api/system/metrics', (req, res) => {
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    const memUsagePercent = ((usedMem / totalMem) * 100).toFixed(1);

    const uptimeSeconds = os.uptime();
    const days = Math.floor(uptimeSeconds / (3600 * 24));
    const hours = Math.floor((uptimeSeconds % (3600 * 24)) / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);

    res.json({
        totalMem: (totalMem / 1024 / 1024 / 1024).toFixed(2),
        usedMem: (usedMem / 1024 / 1024 / 1024).toFixed(2),
        memUsagePercent,
        uptime: `${days}d ${hours}h ${minutes}m`
    });
});

app.post('/api/system/activate', async (req, res) => {
    try {
        const { key } = req.body;

        if (!key) {
            return res.status(400).json({ error: 'Thiếu key kích hoạt' });
        }

        if (!db || !bucket) {
            return res.status(500).json({ error: 'Firebase chưa được cấu hình đúng cách. Kiểm tra serviceAccountKey JSON!' });
        }

        // Validate Key via Realtime Database
        try {
            const keySnap = await db.ref(`activation_keys/${key}`).once('value');
            if (!keySnap.exists()) {
                return res.status(403).json({ error: 'Key kích hoạt không hợp lệ hoặc không tồn tại trên hệ thống Firebase!' });
            }

            // Tùy chọn: Có thể đánh dấu Key đã sử dụng ở đây nếu muốn
            // await db.ref(`activation_keys/${key}/used`).set(true);

        } catch (dbErr) {
            console.error('Firebase DB Error:', dbErr);
            return res.status(500).json({ error: 'Lỗi khi kiểm tra Key trên hệ thống Firebase DB' });
        }

        const isInstalled = fs.existsSync(path.resolve(__dirname, '../nvsoftware.js'));
        if (isInstalled) {
            return res.status(400).json({ error: 'Bot is already installed' });
        }

        const zipPath = path.resolve(__dirname, '../temp_source.zip');
        const extractPath = path.resolve(__dirname, '..');

        // Download from GitHub
        const url = 'https://raw.githubusercontent.com/nvstudio2003-art/alphabot/main/Alphabot.zip';
        try {
            const response = await axios({
                url,
                method: 'GET',
                responseType: 'arraybuffer'
            });

            fs.writeFileSync(zipPath, response.data);

        } catch (downloadErr) {
            console.error('GitHub Download Error:', downloadErr.message);
            return res.status(500).json({ error: 'Lỗi tải source file từ GitHub' });
        }

        const zip = new AdmZip(zipPath);
        const zipEntries = zip.getEntries();
        if (zipEntries.length === 0) throw new Error('Downloaded ZIP is empty');

        const tempExtractPath = path.join(extractPath, 'temp_bot_extract');
        if (fs.existsSync(tempExtractPath)) fs.rmSync(tempExtractPath, { recursive: true, force: true });

        zip.extractAllTo(tempExtractPath, true);

        const items = fs.readdirSync(tempExtractPath);
        let sourceFolder = tempExtractPath;
        if (items.length === 1 && fs.statSync(path.join(tempExtractPath, items[0])).isDirectory()) {
            // Nếu bên trong zip file chỉ chứa duy nhất 1 thư mục gốc
            sourceFolder = path.join(tempExtractPath, items[0]);
        }

        const filesToMove = fs.readdirSync(sourceFolder);
        for (const file of filesToMove) {
            const source = path.join(sourceFolder, file);
            const dest = path.join(extractPath, file);
            if (file !== 'web-gui' && file !== 'package.json' && file !== 'package-lock.json') {
                fs.cpSync(source, dest, { recursive: true, force: true });
            }
        }

        fs.rmSync(tempExtractPath, { recursive: true, force: true });
        fs.unlinkSync(zipPath);
        res.json({ success: true, message: 'Bot source downloaded and extracted' });
    } catch (e) {
        console.error('Activation Error:', e);
        res.status(500).json({ error: e.message || 'Failed to activate' });
    }
});

// --- UPDATE ENDPOINTS ---
app.get('/api/system/check-update', async (req, res) => {
    try {
        if (!db) {
            return res.status(500).json({ error: 'Firebase DB chưa được cấu hình' });
        }

        const packagePath = path.resolve(__dirname, '../package.json');
        let localVersion = '1.0.0';
        if (fs.existsSync(packagePath)) {
            const pkgInfo = JSON.parse(fs.readFileSync(packagePath, 'utf8'));
            localVersion = pkgInfo.version || '1.0.0';
        }

        const verSnap = await db.ref('latest_version').once('value');
        const latestVersion = verSnap.exists() ? String(verSnap.val()) : localVersion;

        // Simple string inequality check
        const hasUpdate = latestVersion !== localVersion;

        res.json({
            hasUpdate,
            localVersion,
            latestVersion
        });
    } catch (e) {
        console.error('Update Check Error:', e);
        res.status(500).json({ error: 'Lỗi kiểm tra bản cập nhật' });
    }
});

app.post('/api/system/update', async (req, res) => {
    try {
        // Tắt bot nếu đang chạy
        if (botProcess && !botProcess.killed) {
            botProcess.kill();
            botProcess = null;
        }

        const zipPath = path.resolve(__dirname, '../temp_update.zip');
        const extractPath = path.resolve(__dirname, '..');

        // Download from GitHub
        const url = 'https://raw.githubusercontent.com/nvstudio2003-art/alphabot/main/Alphabot.zip';
        try {
            const response = await axios({
                url,
                method: 'GET',
                responseType: 'arraybuffer'
            });
            fs.writeFileSync(zipPath, response.data);
        } catch (downloadErr) {
            console.error('Update Download Error:', downloadErr.message);
            return res.status(500).json({ error: 'Lỗi tải bản cập nhật từ GitHub' });
        }

        const zip = new AdmZip(zipPath);
        const zipEntries = zip.getEntries();
        if (zipEntries.length === 0) throw new Error('Downloaded update ZIP is empty');

        const tempExtractPath = path.join(extractPath, 'temp_bot_update');
        if (fs.existsSync(tempExtractPath)) fs.rmSync(tempExtractPath, { recursive: true, force: true });

        zip.extractAllTo(tempExtractPath, true);

        const items = fs.readdirSync(tempExtractPath);
        let sourceFolder = tempExtractPath;

        if (items.length === 1 && fs.statSync(path.join(tempExtractPath, items[0])).isDirectory()) {
            sourceFolder = path.join(tempExtractPath, items[0]);
        }

        const filesToMove = fs.readdirSync(sourceFolder);
        for (const file of filesToMove) {
            const source = path.join(sourceFolder, file);
            const dest = path.join(extractPath, file);

            // Skip overwriting user's private data, configs, and web UI.
            if (file !== 'node_modules' && file !== 'web-gui' && file !== 'appstate.json' && file !== 'settings' && file !== 'package-lock.json') {
                fs.cpSync(source, dest, { recursive: true, force: true });
            }
        }

        fs.rmSync(tempExtractPath, { recursive: true, force: true });
        fs.unlinkSync(zipPath);

        res.json({ success: true, message: 'Cập nhật thành công!' });
    } catch (e) {
        console.error('Update Error:', e);
        res.status(500).json({ error: e.message || 'Lỗi áp dụng bản cập nhật' });
    }
});

app.get('/api/bot/status', (req, res) => {
    res.json({ running: botProcess !== null && !botProcess.killed });
});

app.post('/api/bot/start', (req, res) => {
    if (botProcess && !botProcess.killed) {
        return res.status(400).json({ error: 'Bot is already running' });
    }

    // Spawn the bot process. Use absolute path to ensure accuracy.
    const botScript = path.resolve(__dirname, '../nvsoftware.js');
    botProcess = spawn('node', [botScript], {
        cwd: path.resolve(__dirname, '..'),
        stdio: 'pipe'
    });

    botProcess.stdout.on('data', (data) => {
        console.log(`[BOT OUT]: ${data}`);
    });

    botProcess.stderr.on('data', (data) => {
        console.error(`[BOT ERR]: ${data}`);
    });

    botProcess.on('close', (code) => {
        console.log(`Bot process exited with code ${code}`);
        botProcess = null;
    });

    res.json({ success: true, message: 'Bot started' });
});

app.post('/api/bot/stop', (req, res) => {
    if (!botProcess || botProcess.killed) {
        return res.status(400).json({ error: 'Bot is not running' });
    }

    // Attempt graceful kill first, but treekill is more robust on Windows
    const isWindows = process.platform === 'win32';
    if (isWindows && botProcess.pid) {
        exec(`taskkill /pid ${botProcess.pid} /T /F`, (err) => {
            botProcess = null;
            res.json({ success: true, message: 'Bot forcefully stopped' });
        });
    } else {
        botProcess.kill('SIGKILL');
        botProcess = null;
        res.json({ success: true, message: 'Bot stopped' });
    }
});

app.get('/api/config', (req, res) => {
    try {
        const configData = fs.readFileSync(configPath, 'utf8');
        res.json(JSON.parse(configData));
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.post('/api/config', (req, res) => {
    try {
        fs.writeFileSync(configPath, JSON.stringify(req.body, null, 4), 'utf8');
        res.json({ success: true });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.get('/api/appstate', (req, res) => {
    try {
        const appStatePath = getAppStatePath();
        if (!fs.existsSync(appStatePath)) return res.json([]);
        const stateData = fs.readFileSync(appStatePath, 'utf8');
        res.json(JSON.parse(stateData));
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.post('/api/appstate', (req, res) => {
    try {
        const appStatePath = getAppStatePath();
        const dir = path.dirname(appStatePath);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(appStatePath, JSON.stringify(req.body, null, 2), 'utf8');
        res.json({ success: true });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

const commandsPath = path.resolve(__dirname, '../module/commands');

app.get('/api/commands', (req, res) => {
    try {
        if (!fs.existsSync(commandsPath)) return res.json({});
        const categories = fs.readdirSync(commandsPath, { withFileTypes: true })
            .filter(dirent => dirent.isDirectory())
            .map(dirent => dirent.name);

        const result = {};
        for (const cat of categories) {
            const files = fs.readdirSync(path.join(commandsPath, cat))
                .filter(file => file.endsWith('.js'));
            result[cat] = files;
        }
        res.json(result);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.get('/api/commands/:category/:filename', (req, res) => {
    try {
        const filePath = path.join(commandsPath, req.params.category, req.params.filename);
        if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'Not found' });
        const content = fs.readFileSync(filePath, 'utf8');
        res.json({ content });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.post('/api/commands/:category/:filename', (req, res) => {
    try {
        const dirPath = path.join(commandsPath, req.params.category);
        if (!fs.existsSync(dirPath)) fs.mkdirSync(dirPath, { recursive: true });

        const filePath = path.join(dirPath, req.params.filename);
        fs.writeFileSync(filePath, req.body.content, 'utf8');
        res.json({ success: true });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

const threadsPath = path.resolve(__dirname, '../src/Core/data/threads.json');
app.get('/api/threads', (req, res) => {
    try {
        if (!fs.existsSync(threadsPath)) return res.json({});
        const threadsData = fs.readFileSync(threadsPath, 'utf8');
        res.json(JSON.parse(threadsData));
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

const openBrowser = (url) => {
    const platform = process.platform;
    const isTermux = process.env.TERMUX_VERSION !== undefined ||
        (process.env.HOME && process.env.HOME.includes('com.termux'));

    let cmd;
    if (isTermux) {
        cmd = `termux-open-url ${url}`;
    } else if (platform === 'win32') {
        cmd = `start "" "${url}"`;
    } else {
        cmd = `xdg-open ${url}`;
    }

    exec(cmd, (err) => {
        if (err) console.error('Không thể mở trình duyệt tự động:', err.message);
    });
};

const startServer = (port) => {
    app.listen(port, () => {
        const url = `http://localhost:${port}`;
        console.log(`Web GUI Launcher running at ${url}`);
        openBrowser(url);
    }).on('error', (err) => {
        if (err.code === 'EADDRINUSE') {
            console.log(`Port ${port} is in use, trying ${port + 1}...`);
            startServer(port + 1);
        } else {
            console.error('Server error:', err);
        }
    });
};

startServer(PORT);
