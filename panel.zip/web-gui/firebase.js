import admin from 'firebase-admin';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const serviceAccountPath = path.resolve(__dirname, '../alphabot-v2-firebase-adminsdk-fbsvc-365ec51288.json');

let app;

try {
    if (fs.existsSync(serviceAccountPath)) {
        const serviceAccount = JSON.parse(fs.readFileSync(serviceAccountPath, 'utf8'));
        app = admin.initializeApp({
            credential: admin.credential.cert(serviceAccount),
            databaseURL: `https://${serviceAccount.project_id}-default-rtdb.asia-southeast1.firebasedatabase.app`,
            storageBucket: `${serviceAccount.project_id}.appspot.com`
        });
    } else {
        console.error(`KHÔNG THỂ TÌM THẤY file Firebase Service Account tại: ${serviceAccountPath}`);
    }
} catch (error) {
    console.error('Lỗi khởi tạo Firebase:', error);
}
export const db = app ? admin.database() : null;
export const bucket = app ? admin.storage().bucket() : null;

export default admin;
