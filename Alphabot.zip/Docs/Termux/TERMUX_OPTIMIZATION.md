﻿# ðŸ“± HÆ¯á»šNG DáºªN Tá»I Æ¯U ALPHABOT CHO TERMUX

## ðŸŽ¯ Giá»›i thiá»‡u
PhiÃªn báº£n nÃ y Ä‘Ã£ Ä‘Æ°á»£c tá»‘i Æ°u hÃ³a Ä‘áº·c biá»‡t cho Termux trÃªn Android, giÃºp bot cháº¡y mÆ°á»£t mÃ  vÃ  tiáº¿t kiá»‡m tÃ i nguyÃªn.

## âœ¨ CÃ¡c tá»‘i Æ°u Ä‘Ã£ thá»±c hiá»‡n

### 1. **Tá»‘i Æ°u Memory (Bá»™ nhá»›)**
- âœ… Giá»›i háº¡n heap memory á»Ÿ 512MB
- âœ… Auto garbage collection khi memory cao
- âœ… Cache thÃ´ng minh vá»›i TTL 5 phÃºt
- âœ… Cleanup tá»± Ä‘á»™ng file cache cÅ© (>24h)
- âœ… Giáº£m beautify JSON Ä‘á»ƒ tiáº¿t kiá»‡m disk I/O

### 2. **Tá»‘i Æ°u Performance (Hiá»‡u nÄƒng)**
- âœ… Logging Ä‘Æ°á»£c táº¯t máº·c Ä‘á»‹nh
- âœ… SelfListen táº¯t Ä‘á»ƒ giáº£m xá»­ lÃ½
- âœ… Webview dashboard táº¯t
- âœ… Auto update check táº¯t
- âœ… Giáº£m sá»‘ láº§n restart tá»« 5 â†’ 3
- âœ… TÄƒng thá»i gian refresh state tá»« 12h â†’ 24h
- âœ… TÄƒng thá»i gian refresh MQTT tá»« 2h â†’ 4h

### 3. **Tá»‘i Æ°u Commands**
- âœ… REGBOX_AMOUNT giáº£m tá»« 100 â†’ 50
- âœ… Event logging cÃ³ thá»ƒ táº¯t hoÃ n toÃ n
- âœ… Database khÃ´ng beautify Ä‘á»ƒ giáº£m size

### 4. **linux Scripts**
- âœ… Auto detect Termux environment
- âœ… Memory check trÆ°á»›c khi start
- âœ… Cleanup cache tá»± Ä‘á»™ng
- âœ… ThÃ´ng bÃ¡o rÃµ rÃ ng cho user

## ðŸ“¦ CÃ i Ä‘áº·t trÃªn Termux

### BÆ°á»›c 1: CÃ i Ä‘áº·t dependencies
```bash
# Update packages
pkg update && pkg upgrade -y

# CÃ i Node.js
pkg install nodejs-lts -y

# CÃ i Git (náº¿u cáº§n)
pkg install git -y
```

### BÆ°á»›c 2: Clone/Extract bot
```bash
cd ~
# Náº¿u báº¡n Ä‘Ã£ cÃ³ folder, cd vÃ o folder Ä‘Ã³
cd Alphabot
```

### BÆ°á»›c 3: CÃ i Ä‘áº·t packages
```bash
# Sá»­ dá»¥ng config tá»‘i Æ°u cho Termux
cp settings/config.termux.json settings/config.main.json

# CÃ i Ä‘áº·t packages (cÃ³ thá»ƒ máº¥t 5-10 phÃºt)
bash linux/Setup.sh
```

### BÆ°á»›c 4: Login
```bash
# ÄÄƒng nháº­p báº±ng appstate
bash linux/Login.sh
```

### BÆ°á»›c 5: Cháº¡y bot
```bash
# Khá»Ÿi Ä‘á»™ng bot
bash linux/Start.sh
```

## ðŸ”§ Cáº¥u hÃ¬nh tá»‘i Æ°u

### File: `settings/config.termux.json`
Config nÃ y Ä‘Ã£ Ä‘Æ°á»£c tá»‘i Æ°u cho Termux:

```json
{
  "LOG_LEVEL": 0,                    // Táº¯t logging
  "DATABASE_JSON_BEAUTIFY": false,   // KhÃ´ng beautify JSON
  "REFRESH": "86400000",             // Refresh má»—i 24h
  "GBOTWAR_OPTIONS": {
    "WEBVIEW": false,                // Táº¯t dashboard
    "LISTEN_CONSOLE": false,         // Táº¯t console log
    "REGBOX_AMOUNT": 50,             // Giáº£m sá»‘ box
    "NOTIFICATION_DISPLAY": false,   // Táº¯t thÃ´ng bÃ¡o
    "ALERT_UPDATE": false            // Táº¯t check update
  }
}
```

## ðŸ’¡ Tips & Tricks

### 1. Giáº£m tiÃªu thá»¥ pin
```bash
# Cháº¡y trong background vá»›i tmux/screen
pkg install tmux -y
tmux new -s bot
cd Alphabot && bash linux/Start.sh
# Nháº¥n Ctrl+B rá»“i D Ä‘á»ƒ detach
```

### 2. Auto restart khi crash
```bash
# Táº¡o file restart.sh
cat > restart.sh << 'EOF'
#!/bin/bash
while true; do
    cd ~/Alphabot
    bash linux/Start.sh
    echo "Bot Ä‘Ã£ dá»«ng, chá» 10s rá»“i restart..."
    sleep 10
done
EOF

chmod +x restart.sh
./restart.sh
```

### 3. Monitor memory usage
```bash
# Xem memory Ä‘ang dÃ¹ng
free -h

# Xem process cá»§a bot
ps aux | grep node
```

### 4. Cleanup manual
```bash
# Dá»n cache thá»§ cÃ´ng
npm run cleanup

# XÃ³a node_modules vÃ  reinstall (náº¿u cÃ³ lá»—i)
rm -rf node_modules
npm install
```

## âš ï¸ LÆ°u Ã½ quan trá»ng

1. **KhÃ´ng táº¯t mÃ n hÃ¬nh khi Ä‘ang cÃ i packages**
   - Termux cÃ³ thá»ƒ bá»‹ kill process khi mÃ n hÃ¬nh táº¯t lÃ¢u
   - Sá»­ dá»¥ng Termux:Wake Lock hoáº·c giá»¯ mÃ n hÃ¬nh sÃ¡ng

2. **Storage permission**
   ```bash
   termux-setup-storage
   ```

3. **Keep Termux alive**
   - Äi vÃ o Settings â†’ Battery â†’ Termux â†’ Unrestricted
   - Táº¯t battery optimization cho Termux

4. **RAM requirements**
   - Tá»‘i thiá»ƒu: 1GB RAM cÃ²n trá»‘ng
   - Khuyáº¿n nghá»‹: 2GB+ RAM

5. **KhÃ´ng cháº¡y quÃ¡ nhiá»u command cÃ¹ng lÃºc**
   - CÃ¡c lá»‡nh spam, regbox cÃ³ thá»ƒ lÃ m Ä‘áº§y memory
   - NÃªn giá»›i háº¡n sá»‘ lÆ°á»£ng vÃ  thá»i gian

## ðŸ› Troubleshooting

### Lá»—i: "JavaScript heap out of memory"
```bash
# TÄƒng memory limit
export NODE_OPTIONS="--max-old-space-size=768"
node nhatcoder.js
```

### Lá»—i: "ENOSPC: no space left on device"
```bash
# XÃ³a cache
npm run cleanup

# XÃ³a npm cache
npm cache clean --force
```

### Bot bá»‹ crash liÃªn tá»¥c
```bash
# Check log
cat nohup.out  # náº¿u dÃ¹ng nohup

# Reduce memory usage
# Táº¯t thÃªm features trong config.main.json
```

### Lá»‡nh khÃ´ng hoáº¡t Ä‘á»™ng
```bash
# Check permissions
ls -la Scripts/commands/

# Re-copy config
cp settings/config.termux.json settings/config.main.json
```

## ðŸ“Š Benchmark

Vá»›i cáº¥u hÃ¬nh tá»‘i Æ°u:
- **Memory usage**: ~200-300MB (thay vÃ¬ 500-800MB)
- **CPU usage**: ~5-15% (Snapdragon 600+)
- **Battery drain**: ~10-15%/hour
- **Startup time**: 15-30 giÃ¢y

## ðŸ†˜ Há»— trá»£

Náº¿u gáº·p váº¥n Ä‘á»:
- Facebook: https://www.facebook.com/vuminhnhat10092003
- Zalo: 0348253995
- Email: nhatcoder2003@gmail.com

## ðŸ“ Changelog

**Version 1.1 - Termux Optimized**
- ThÃªm memory optimizer
- Tá»‘i Æ°u refresh intervals
- Táº¯t features khÃ´ng cáº§n thiáº¿t
- Auto cleanup cache
- linux scripts cho Termux
- Memory checks vÃ  warnings

---

**ChÃºc báº¡n sá»­ dá»¥ng bot vui váº»! ðŸš€**

