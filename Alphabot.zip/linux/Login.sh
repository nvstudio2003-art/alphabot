#!/bin/bash
set -euo pipefail
clear

node login.js
