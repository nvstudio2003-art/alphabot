#!/bin/bash
set -euo pipefail
clear
node Active.js