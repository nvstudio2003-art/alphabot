# ALPHABOT
<p align="center">
    <a href="https://github.com/nhatcoder2003/Gbot-War">
        <img src="https://about.nhatcoder.id.vn/logo.png" alt="Logo">
    </a>
    </p>


>  Mọi vấn đề bản quyền hãy gửi mail cho tôi qua ___nhatcoder2003@gmail.com___
    

## ABOUT

___Author: XaviaTeam___

___Editor: Nhat Vu___

___Email: nhatcoder2003@gmail.com___

___Phone or Zalo: +84348253995___

___Website: https://about.nhatcoder.id.vn___

___Blog: https://nhatcoder2k3.name.vn___

### SOCIAL

- [Facebook](https://www.facebook.com/vuminhnhat10092003)

- [Youtube](https://www.youtube.com/@nvcoder)

- [Discord](https://discord.com/channels/@me/1077229600817557566)
    

__Thank to XaviaTeam__

# HƯỚNG DẪN CÀI ĐẶT

## Cài Đặt Termux

- Để chạy được dự án mọi người cần cài đặt termux phiên bản mới nhất ở dưới đây (phiên bản chplay đã ngưng cập nhật)
https://f-droid.org/packages/com.termux/

## Cài đặt các thư viện cần thiết
```pkg update && pkg upgrade && pkg install nodejs && pkg install git && pkg install python```

## Tải về dự án
- Để tải về phiên bản mới nhất của dự án này các bạn chạy dòng lệnh dưới
```git clone https://github.com/nhatcoder2003/Alphabot-V2.git```

## Thiết lập dự án
 - Sử dụng lệnh ``cd Alphabot`` để truy cập vào thư mục dự án

- Chạy dòng lệnh bên dưới để cài đặt các thư mục cần thiết 

```
npm run setup
```

- Sau khi tiến hành cài đặt thư viện và đăng nhập tài khoản bot và thêm ID SUPPER ADMIN

- Hệ thống sẽ đưa bạn sang bước nhập key bạn hãy nhập key mua từ admin để kích hoạt bot

- Bước cuối cùng để chạy bot là:
```
npm run start
```

## Cấu trúc thư mục

### Cấu trúc tối ưu và chuyên nghiệp

```
Alphabot/
├── src/          # Core runtime engine
│   ├── Core/        # Hệ thống lõi
│   │   ├── helpers/ # Runtime utilities (runtime.js, projectPaths.js, memoryOptimizer.js)
│   │   ├── controllers/ # Thread & User controllers
│   │   ├── models/  # Data models
│   │   └── data/    # Persistent data storage
│   ├── Handlers/    # Event & database handlers
│   └── Banner.js    # UI banner
│
├── Scripts/         # Bot functionality
│   ├── commands/    # Command handlers (Admin, War, Auto, Anti)
│   ├── events/      # Event listeners (subscribe, nickname, etc.)
│   ├── customs/     # Custom handlers
│   └── onMessage/   # Message processors
│
├── Tools/           # Utility scripts
│   ├── Termux/      # Termux optimizations
│   └── Maintenance/ # Cleanup utilities
│
├── Docs/            # Documentation
│   └── Termux/      # Termux guides
│
├── resources/       # Bot resources
│   ├── Lyrics/      # Spam/War content
│   └── Data/        # Runtime data
│
├── settings/          # Configuration files
├── linux/           # linux scripts (Start, Setup, Login, etc.)
└── vendor/          # Dependencies (nv-fca)
```

### Tính năng lõi

- **Centralized Runtime**: Tất cả environment detection và utilities tập trung trong `src/Core/helpers/`
- **Modular Architecture**: Commands, events, và handlers được tách biệt rõ ràng
- **Memory Optimization**: Tích hợp GC và memory management cho Termux
- **Path Management**: Tất cả đường dẫn được quản lý tập trung qua `projectPaths.js`
- `Tools/Maintenance/`: Script bảo trì (`cleanup.js`)
- `Docs/Termux/`: Tài liệu tối ưu Termux
- `resources/`: Bot data và lyrics resources
- `vendor/`: External dependencies (nv-fca)

### Core conventions

- Shared runtime env/interval/GC logic: `src/Core/helpers/runtime.js`
- Shared project absolute paths: `src/Core/helpers/projectPaths.js`
- Hạn chế hard-code path và env check trực tiếp trong module mới

## Lệnh nhanh (Termux)

```bash
npm run termux
npm run cleanup
npm run memory
npm run termux:quickstart
```
