//source: Github

//source: Github

const isWin = process.platform === "win32";
const isLinux = process.platform === "linux";

export default { isWin, isLinux };
