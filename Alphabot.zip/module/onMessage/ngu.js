function Running({message}){
  if(message.body === "ngu"){
    message.reply("Ai ngu, box này chỉ có thằng Bảo là óc lồn nhất");
  }
}
export default {
  Running
}