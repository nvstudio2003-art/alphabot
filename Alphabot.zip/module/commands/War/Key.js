const config = {
  name: "key",
  description: "Giá bot",
  version: "1.0.0",
  cooldown: 3,
  permissions: [2],
  credits: "Nhật Ngáo"
}

async function Running( {
  message
}) {
  message.reply(`〖  𝑨𝑳𝑷𝑯𝑨𝑩𝑶𝑻 - 𝑳𝑨𝑴 𝑪𝑯𝑼 𝑺𝑨𝑵 𝑾𝑨𝑹〗\n👉 𝑫𝒆𝒗𝒆𝒍𝒐𝒑𝒆𝒓𝒔: 𝑵𝒉𝒂𝒕𝒄𝒐𝒅𝒆𝒓2003\n👉𝒁𝒂𝒍𝒐 𝒐𝒓 𝑷𝒉𝒐𝒏𝒆: 0348253995\n👉𝑭𝒂𝒄𝒆𝒃𝒐𝒐𝒌: https://www.facebook.com/profile.php?id=100023986450526\n👉𝑾𝒆𝒃𝒔𝒊𝒕𝒆: https://www.nhatcoder2k3.name.vn\n𝑩𝒂𝒏𝒌: 1027891841 [Vu Minh Nhat - Vietcombank]\n〘 Bảng giá mua key 〙\n1𝒎𝒐𝒏𝒕𝒉/50𝒌\n3𝒎𝒐𝒏𝒕/100𝒌\n1𝒚𝒆𝒂𝒓/500𝒌\n𝑼𝒏𝒍𝒊𝒎𝒊𝒕𝒆𝒅/1000𝒌\n👉Chúng tôi luôn cung cấp những bản cập nhật cho BOT giúp bạn làm chủ sàn war dễ dàng hơn\n👉Ngoài ra chúng tôi còn hỗ trợ setup cho bạn nếu bạn không biết cài đặt\nP/S: CỨ LẤY TIỀN ĐẬP VÀO MẶT TÔI BẠN CÓ THỂ YÊU CẦU BẤT CỨ ĐIỀU GÌ`);
}

export default {
  config,
  Running
}